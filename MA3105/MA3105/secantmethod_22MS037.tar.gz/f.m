function y=f(x)

  y = x.^6 -x-1;
end
